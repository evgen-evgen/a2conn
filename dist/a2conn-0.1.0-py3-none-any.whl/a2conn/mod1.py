print('This is mod1!!!!!!!')

shima = "!!!!!!!!!!!!!  Hello,Shima !!!!!!!!!!!!!!!!!! "
dima = "!!!!!!!!!!!!!! Hello, Dima !!!!!!!!!!!!!!!!!!"